Print[WolframAlpha["e^2 x cos(3x)", IncludePods -> {"Indefinite Integral"}, PodStates -> {"Step-by-step solution", "Show all steps"}]]
