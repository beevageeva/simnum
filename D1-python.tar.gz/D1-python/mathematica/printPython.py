print("%% AMS-LaTeX Created by Wolfram Mathematica 9.0 : www.wolfram.com\n\n\\documentclass{article}\n\\usepackage{amsmath, amssymb, graphics, \
setspace}\n\n\\newcommand{\\mathsym}[1]{{}}\n\\newcommand{\\unicode}[1]{{}}\n\n\\newcounter{mathematicapage}\n\\begin{document}\n\n\\[\\fra\
c{1}{2} e^{-\\frac{\\pi  \\left(\\text{k0}^2 \\pi  W^2+m \\left(m \\pi  W^2-2 i \\text{zc} (\\text{z0}-\\text{zf})\\right)+2 \\text{k0} \
\\left(m \\pi  W^2+i\n(\\text{z0}+\\text{zc}) (\\text{z0}+\\text{zf})\\right)\\right)}{(\\text{z0}-\\text{zf})^2}} \\left(e^{\\frac{4 i \
\\text{k0} \\pi  \\text{z0} (\\text{zc}+\\text{zf})}{(\\text{z0}-\\text{zf})^2}}+e^{\\frac{4\n\\text{k0} \\pi  \\left(m \\pi  W^2+i \
\\left(\\text{z0}^2+\\text{zc} \\text{zf}\\right)\\right)}{(\\text{z0}-\\text{zf})^2}}\\right) \\sqrt{\\pi } W\\]\n\n\\end{document}\n")
print("%% AMS-LaTeX Created by Wolfram Mathematica 9.0 : www.wolfram.com\n\n\\documentclass{article}\n\\usepackage{amsmath, amssymb, graphics, \
setspace}\n\n\\newcommand{\\mathsym}[1]{{}}\n\\newcommand{\\unicode}[1]{{}}\n\n\\newcounter{mathematicapage}\n\\begin{document}\n\n\\[\\fra\
c{1}{2} \\left(e^{-\\frac{\\pi  \\left(\\text{k0}^2 \\pi  W^2-2 \\text{k0} \\left(k \\pi  W^2-i \\text{z0}+i \\text{zc}\\right) \
(\\text{z0}-\\text{zf})+k\n\\left(k \\pi  W^2+2 i \\text{zc}\\right) \
(\\text{z0}-\\text{zf})^2\\right)}{(\\text{z0}-\\text{zf})^2}}+e^{-\\frac{\\pi  \\left(\\text{k0}^2 \\pi  W^2+2 \\text{k0}\n\\left(k \\pi  \
W^2-i \\text{z0}+i \\text{zc}\\right) (\\text{z0}-\\text{zf})+k \\left(k \\pi  W^2+2 i \\text{zc}\\right) \
(\\text{z0}-\\text{zf})^2\\right)}{(\\text{z0}-\\text{zf})^2}}\\right)\n\\sqrt{\\pi } W\\]\n\n\\end{document}\n")
